const readline = require("node:readline/promises");
const { stdin: input, stdout: output } = require("node:process");
const { Chat } = require("polyfact");
const { Worker } = require("worker_threads");

const chatQueue = {} // Global chat queue

function generateChatId(msgCount, persons, subject) {
  const chatId = Date.now().toString(); // Generate a unique chat ID based on the current timestamp

  const chat = {
    id: chatId,
    messages: [],
    persons,
    subject,
    msgCount,
  };

  chatQueue[chatId] = chat; // Add the chat to the queue

  // Process the chat request in the background
  console.log("Processing chat: ", chatId);
  processChat(chat);

  return chatId;
}

async function processChat(chat) {
  while (chat.messages.length < chat.msgCount) {
    const chatInstance = new Chat({
      systemPrompt: `You are simulating just the next message stereotypical chat between ${chat.persons[chat.messages.length % 2]} and ${chat.persons[(chat.messages.length % 2) === 1 ? 0 : 1]}. They are talking about '${chat.subject}'.\nRespond with just the next message said by ${chat.persons[chat.messages.length % 2]}. Each message is a very short text message containing only ONE OR TWO SENTENCES UNDER 10 WORDS. Make the messages very funny and based to their stereotypes irl if they're a famous person.\nPLEASE RESPOND WITH ONE MESSAGE AT A TIME ONLY ONE MESSAGE. DO NOT COMBINE MULTIPLE PEOPLE INTO A MESSAGE. ALWAYS ALWAYS PUT THE PERSON WHO SAID IT BEFORE THE MESSAGE SEPERATED BY A COLON. THE NEXT MESSAGE IS SAID BY ${chat.persons[chat.messages.length % 2]}. So the output should start with '${chat.persons[chat.messages.length % 2]}: {their response}'`,
    });

    const aiAnswer = await chatInstance.sendMessage(
      chat.messages.length === 0
        ? `${chat.persons[1]}: hey lets talk about ${chat.subject}`
        : chat.messages.map((e, i) => `${e}`).join("\n")
    );

    console.log(aiAnswer);
    chat.messages.push(aiAnswer);
    chatQueue[chat.id].messages = chat.messages
  }

  console.log(chat.messages);
}


const express = require('express')
const app = express()
const port = 3000
var bodyParser = require('body-parser')
app.use(bodyParser.json())

app.use(express.static('public'))

app.post('/newChat', (req,res) => {
  console.log("fgdfg")
  const {person1, person2, prompt, length} = req.body;
  const chatId = generateChatId(length, [person1, person2], prompt);
  res.send(JSON.stringify({
    chatId
  }))
})

app.get('/chat', (req,res) => {
  const {id} = req.query;
  console.log(id)
  res.send(JSON.stringify({
    data: chatQueue[id]
  }))
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})