const { parentPort } = require("worker_threads");

function processChat(chat) {
  while (chat.messages.length < chat.msgCount) {
    // Simulate chat processing
    const aiAnswer = `AI response for chat ${chat.id}, message ${chat.messages.length + 1}`;
    chat.messages.push(aiAnswer);
  }

  parentPort.postMessage({ chatId: chat.id, messages: chat.messages });
}

parentPort.on("message", (message) => {
  const { chatId, messages } = message;
  const chat = { id: chatId, messages };
  processChat(chat);
});